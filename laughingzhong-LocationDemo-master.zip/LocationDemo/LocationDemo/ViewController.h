//
//  ViewController.h
//  LocationDemo
//
//  Created by LaughingZhong on 14/11/12.
//  Copyright (c) 2014年 Laughing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController<CLLocationManagerDelegate,MKMapViewDelegate>
{
    IBOutlet UILabel *label;
}

@property(strong,nonatomic) CLLocationManager *myLocationManager;
@property(strong,nonatomic) CLGeocoder *myGeocoder;
@property(strong,nonatomic) CLLocation *myLocation;

@end
